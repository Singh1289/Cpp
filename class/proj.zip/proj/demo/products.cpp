

#include"products.h"
void products::
accept_pro(){
        cout<<"\n";
        cout<<"enter product id : ";
        int *iptr=new int;
        cin>>*iptr;
        id.push_back(iptr);
        cout<<"enter product name : ";
        string*pptr=new string;
        cin>>*pptr;
        pro_name.push_back(pptr);
        cout<<"enter product price : ";
        double *dptr=new double;
        cin>>*dptr;
        price.push_back(dptr);
        cout<<"\n";
            }

            void products:: display_pro(){
        for(int i=0;i<pro_name.size();i++){
        cout<<"\n";    
        cout<<"product id : "<<*id[i]<<endl;
        cout<<"product name : "<<*pro_name[i]<<endl;
        cout<<"product price : "<<*price[i]<<endl;
        cout<<"\n";}
    }
    int products::get_size(){
        return pro_name.size();
    }
    string products::get_pro_name(int i){
   
        return *pro_name[i];
        
    }
