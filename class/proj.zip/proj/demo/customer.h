#ifndef CUSTOMER_H
#define CUSTOMER_H
#include"person.h"
class customer:public person
 {
    string mobile_no;
    string purchased_pro1;
    products p1;
    public :
    virtual void accept();
    string get_mo();
    void add_pro();
    virtual void display();
    void purchased_pro();

};
#endif