
#include"products.h"
#include"person.h"
#include"customer.h"
#include"display.h"
#include"menu.h"
int main(){
    int choice;
    vector <person *>person_list;
    person *ptr;
    customer *cptr;
    while(choice=menu()){
    switch (choice)
    {

    case 2:
        ptr = new customer();
        ptr->accept();
        person_list.push_back(ptr);
        break;

        case 4:
        {string name2;
        cout<<"enter name :";
        cin>>name2;
        for(int i=0;i<person_list.size();i++)
        if(person_list[i]->getname()==name2)
        {cptr=(customer*)person_list[i];
            cptr->purchased_pro();
        }
        
        }
        break;
        case 3:
        {string name1;
        cout<<"enter name :";
        cin>>name1;
        for(int i=0;i<person_list.size();i++)
        if(person_list[i]->getname()==name1)
        {cptr=(customer*)person_list[i];
            cptr->add_pro();
        }
        
        }
        break;
        case 1:
        display_products();
        break;
        case 5:{
        {string name1;
        cout<<"enter name :";
        cin>>name1;
        for(int i=0;i<person_list.size();i++)
        if(person_list[i]->getname()==name1)
        {cptr=(customer*)person_list[i];
            cptr->display();
        }
        }}
        break;
    
    default:
        cout<<"invalid choice!!"<<endl;
        break;
    }}
    return 0;
    }