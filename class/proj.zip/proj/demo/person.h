#ifndef PERSON_H
#define PERSON_H
#include"products.h"
using namespace std;
class person {
   string name;
    public :
    virtual void accept();
    string getname();
    virtual void display();

};
#endif