#include"person.h"
 void person::accept(){
        cout<<"enter name : ";
        cin>>name;
    }
    string person:: getname(){
    return name;
    }
     void person:: display(){
        cout<<"name : "<<name;
            }