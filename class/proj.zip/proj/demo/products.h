#ifndef PRODUCT_H
#define PRODUCT_H
#include <vector>
#include <iostream>
using namespace std;
class products {
    vector<int*>id;
    vector<double*> price;
    vector <string*> pro_name;
    public:
    void acceptname();
    void accept_pro();
    void display_pro();
    int get_size();
    string get_pro_name(int i);


};
#endif