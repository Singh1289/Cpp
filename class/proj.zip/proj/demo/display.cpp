
#include"display.h"
#include<iostream>
using namespace std;
void display_products(){
    std::cout<<"\n";
    cout<<"1.laptop"<<endl;
    cout<<"2.camera"<<endl;
    cout<<"3.watches"<<endl;
    cout<<"\n";
}