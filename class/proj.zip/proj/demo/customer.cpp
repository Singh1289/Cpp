
#include"customer.h"

     void customer:: accept(){
        person::accept();
        cout<<"enter mobile no : ";
        cin>>mobile_no;
        
    }
    string customer:: get_mo(){
    return mobile_no;
    }
    void customer:: add_pro(){
        cout<<"enter product to purchase : ";
        p1.accept_pro();
    }
     void customer::display(){
        person::display();
        cout<<"mobile no : "<<mobile_no<<endl;
        p1.display_pro();
    }
    void customer::purchased_pro(){
        cout<<"\n";
         cout<<"purchased products : "<<endl;
         for(int i=0;i<p1.get_size();i++){
        purchased_pro1=p1.get_pro_name(i);
      cout <<purchased_pro1<<endl;}
    }
