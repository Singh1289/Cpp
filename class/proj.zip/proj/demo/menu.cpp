#include"menu.h"
#include<iostream>
using namespace std;
int menu(){
    int choice;
    std::cout<<"\n";
    cout<<"0.exit"<<endl;
    cout<<"1.display products"<<endl;
    cout<<"2.new customer"<<endl;
    cout<<"3.add produc"<<endl;
    cout<<"4.display product purchased"<<endl;
    cout<<"5.display product details :"<<endl;
    cout<<"6.enter choice : ";
    cin>>choice;
    return choice;
}